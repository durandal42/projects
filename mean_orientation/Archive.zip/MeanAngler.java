public interface MeanAngler {
  public double averageAngle(double maxAngle, double[] angles);
}